# -*- coding: utf-8 -*-

from odoo import models, api, exceptions


class StockQuant(models.Model):
    _inherit = 'stock.quant'

    @api.model
    def write(self, vals):
        if not self.env.user.has_group('restricted_adjustment.group_stock_quant_editor'):
            raise exceptions.UserError("You do not have permission to modify or save this record.")

        return super(StockQuant, self).write(vals)

