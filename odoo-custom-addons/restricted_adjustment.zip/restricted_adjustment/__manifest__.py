# -*- coding: utf-8 -*-
{
    'name': "Restricted Adjustment",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,

    'author': "Hamza",


    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base','product','mrp'],

    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/views.xml',
    ],
    # only loaded in demonstration mode

}

